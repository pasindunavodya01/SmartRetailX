const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { PutCommand, DynamoDBDocumentClient } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));
  
  if (!event.Records) return { statusCode: 200, body: 'No records' };
  
  for (const record of event.Records) {
    let payload;
    let messageId;
    
    if (record.Sns) {
      messageId = record.Sns.MessageId;
      try {
        payload = JSON.parse(record.Sns.Message);
      } catch(e) {
        payload = record.Sns.Message;
      }
    } else {
      payload = record;
      messageId = Date.now().toString();
    }
    
    const eventId = payload.orderId || payload.id || messageId;
    
    const command = new PutCommand({
      TableName: process.env.DYNAMODB_TABLE,
      Item: {
        EventId: eventId,
        Timestamp: new Date().toISOString(),
        Status: payload.status || 'LOGGED',
        RawData: JSON.stringify(payload)
      }
    });
    
    await docClient.send(command);
    console.log(`Successfully logged event ${eventId} to DynamoDB`);
  }
  
  return { statusCode: 200, body: 'Processed' };
};
